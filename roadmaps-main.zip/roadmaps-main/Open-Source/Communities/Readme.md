## Communities you can join 👇

- [Community Classroom](https://discord.io/commclassroom)
- [Eddiehub](http://discord.eddiehub.org/)
- [Geek Around Community](https://discord.io/geekaroundcommunity)
- [MLH](https://discord.gg/mlh)
- [Sema](http://discord.gg/Byjr6rdBUZ)
- [cs dojo](https://discord.gg/H5WBXpsu)
