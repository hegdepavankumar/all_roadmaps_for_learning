## Communities you can join 👇

- [Community Classroom](https://discord.io/commclassroom)
- [Eddiehub](http://discord.eddiehub.org/)
- [MLH](https://discord.gg/mlh)
- [AndroidDev](https://discord.gg/gjPP5f5z)
