## Communities you can join 👇

- [Community Classroom](https://discord.io/commclassroom)
- [Eddiehub](http://discord.eddiehub.org/)
- [MLH](https://discord.gg/mlh)
- [Kubesimplify](https://kubesimplify.com/discord)
- [KubeWorld](https://discord.io/kubeworld)
- [Kubernetes Twitter](https://twitter.com/i/communities/1444745802383953921)
- [Kubernetes Slack](https://kubernetes.slack.com/)
- [CNCF Slack](https://slack.cncf.io/)
- [DoK Slack](https://go.dok.community/slack)
- [Gopher Slack](https://invite.slack.golangbridge.org/)
- [Kubescape Discord](https://discord.com/invite/WKZRaCtBxN)
